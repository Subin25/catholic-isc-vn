
import fs from 'node:fs';
import ical from 'ical-generator';
import { Romcal } from 'romcal';
import { Vietnam_Vi } from '@romcal/calendar.vietnam';

const toStartUTC = (d) => new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0));
const toEndUTC   = (d) => new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59));

const isSolemnity = (c) => {
  const r = (c.rank?.toString() || c.rankName || c.type || '').toLowerCase();
  return r.includes('solemnity') || r.includes('lễ trọng');
};

async function make(year) {
  const romcal = new Romcal({ localizedCalendar: Vietnam_Vi, scope: 'gregorian' });
  const celebrations = await romcal.generateCalendar({ year });
  const cal = ical({ name: `Lịch Công giáo VN – Lễ Trọng (${year})`, timezone: 'Asia/Ho_Chi_Minh' });

  celebrations.filter(isSolemnity).forEach((c) => {
    const d = new Date(c.date);
    cal.createEvent({
      start: toStartUTC(d),
      end: toEndUTC(d),
      summary: c.name || c.key || 'Lễ Trọng',
      description: 'Lễ Trọng (Romcal)',
      allDay: true,
    });
  });

  return cal.toString();
}

const now = new Date();
const y1 = now.getUTCFullYear();
const y2 = y1 + 1;

const ics1 = await make(y1);
const ics2 = await make(y2);

const events = (ics) => ics.split('\n').filter(l =>
  l.startsWith('BEGIN:VEVENT') ||
  l.startsWith('END:VEVENT') ||
  l.startsWith('DT') ||
  l.startsWith('UID') ||
  l.startsWith('SUMMARY') ||
  l.startsWith('DESCRIPTION')
);

const body = [
  'BEGIN:VCALENDAR',
  'VERSION:2.0',
  'PRODID:-//dinhhsam//catholic-ics//VI',
  ...events(ics1),
  ...events(ics2),
  'END:VCALENDAR',
  ''
].join('\r\n');

fs.mkdirSync('public', { recursive: true });
fs.writeFileSync('public/vietnam-solemnities.ics', body, 'utf8');
console.log('wrote public/vietnam-solemnities.ics');
