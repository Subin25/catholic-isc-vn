
# Vietnam Catholic Solemnities ICS (Auto-updated)

This repo builds a single ICS feed with **Vietnam national liturgical calendar** (Romcal) filtered to **Solemnities** only. It auto-updates weekly via GitHub Actions and serves via **GitHub Pages** at:

`https://<your-username>.github.io/<repo>/vietnam-solemnities.ics`

## Quick start
1. Create a **public** repo on GitHub (any name).
2. Upload / push all files from this folder.
3. In the repo, go to **Settings → Pages**, set **Source = GitHub Actions**.
4. Wait for the workflow to complete (Actions tab).
5. Copy the Pages URL and append `/vietnam-solemnities.ics`.

## Add to Google Calendar
On desktop: Google Calendar → **Add other calendars → From URL** → paste the URL above.

## Notes
- Uses `romcal` + `@romcal/calendar.vietnam` for the Vietnam national calendar.
- We generate current year + next year into one feed.
- To include **Feasts** too, tweak `isSolemnity` in `export.mjs`.
